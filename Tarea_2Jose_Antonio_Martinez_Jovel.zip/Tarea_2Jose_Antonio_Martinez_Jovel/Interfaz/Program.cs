﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaz
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int var;
            ClaseSamsung samsung = new ClaseSamsung("Samsung A30s", "SAMSUNG", "Android 9", 32, 290);
            ClaseApple apple = new ClaseApple("iPhone 13 Pro Max", "iPhone", "iOS 15", 256, 1200);
            ClaseXiaomi xiaomi = new ClaseXiaomi("Xiaomi Poco X3 GT", "Xiaomi", "Android", 256, 429);
            ClaseHuawei huawei = new ClaseHuawei("Nova 8i", "Huawei", "Android", 128, 389);
            //----------------------------------------------------------------------------------------------------

            Console.WriteLine("\t---------- CATALOGO DE CELULARES ----------");
            Console.WriteLine("\tVer informacion de celulares (Presione 1)");
            Console.WriteLine("\tSALIR (Presione 0)");
            var = int.Parse(Console.ReadLine());
            switch (var)
            {
                case 1:
                    Console.Clear();
                    Console.WriteLine("----- PRODUCTO # 1-----");
                    Console.WriteLine("NOMBRE: " + samsung.Nombre);
                    Console.WriteLine("MARCA: " + samsung.Marca);
                    Console.WriteLine("SISTEMA: " + samsung.Software);
                    Console.WriteLine("ALMACENAMIENTO: " + samsung.Almacenamiento + " GB");
                    Console.WriteLine("PRECIO: $" + samsung.Precio + "\n");
                    Console.WriteLine("----- PRODUCTO # 2-----");
                    Console.WriteLine("NOMBRE: " + apple.Nombre);
                    Console.WriteLine("MARCA: " + apple.Marca);
                    Console.WriteLine("SISTEMA: " + apple.Software);
                    Console.WriteLine("ALMACENAMIENTO: " + apple.Almacenamiento + " GB");
                    Console.WriteLine("PRECIO: $" + apple.Precio + "\n");
                    Console.WriteLine("----- PRODUCTO # 3-----");
                    Console.WriteLine("NOMBRE: " + xiaomi.Nombre);
                    Console.WriteLine("MARCA: " + xiaomi.Marca);
                    Console.WriteLine("SISTEMA: " + xiaomi.Software);
                    Console.WriteLine("ALMACENAMIENTO: " + xiaomi.Almacenamiento + " GB");
                    Console.WriteLine("PRECIO: $" + xiaomi.Precio + "\n");
                    Console.WriteLine("----- PRODUCTO # 4-----");
                    Console.WriteLine("NOMBRE: " + huawei.Nombre);
                    Console.WriteLine("MARCA: " + huawei.Marca);
                    Console.WriteLine("SISTEMA: " + huawei.Software);
                    Console.WriteLine("ALMACENAMIENTO: " + huawei.Almacenamiento + " GB");
                    Console.WriteLine("PRECIO: $" + huawei.Precio + "\n");
                    break;
                case 0:
                    Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("Error");
                    break;
            }
            Console.ReadKey();
        }
    }
}
