﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaz
{
    public class ClaseSamsung:ICelular
    {
        public string Nombre { get; set; }
        public string Marca { get; set; }
        public string Software { get; set; }
        public int Almacenamiento { get; set; }
        public float Precio { get; set; }

        // Constructores
        public ClaseSamsung()
        {
            Nombre = string.Empty;
            Marca = string.Empty;
            Software = string.Empty;
            Almacenamiento = 0;
            Precio = 0;
        }
        public ClaseSamsung(string nombre, string marca, string software, int almacenamiento, float precio)
        {
            Nombre = nombre;
            Marca = marca;
            Software = software;
            Almacenamiento = almacenamiento;
            Precio = precio;
        }

    }
}
