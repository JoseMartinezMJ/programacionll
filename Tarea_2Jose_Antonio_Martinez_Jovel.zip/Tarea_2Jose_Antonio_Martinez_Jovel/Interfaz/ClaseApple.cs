﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaz
{
    public class ClaseApple:ICelular
    {
        public string Nombre { get; set; }
        public string Marca { get; set; }
        public string Software { get; set; }
        public int Almacenamiento { get; set; }
        public float Precio { get; set; }

        // Constructores
        public ClaseApple()
        {
            Nombre = string.Empty;
            Marca = string.Empty;
            Software = string.Empty;
            Almacenamiento = 0;
            Precio = 0;
        }
        public ClaseApple(string nombre, string marca, string software, int almacenamiento, float precio)
        {
            Nombre = nombre;
            Marca = marca;
            Software = software;
            Almacenamiento = almacenamiento;
            Precio = precio;
        }
    }
}
