﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaz
{ public interface ICelular
    {
        string Nombre { get; set; }
        string Marca { get; set; }
        string Software { get; set; }
        int Almacenamiento { get; set; }
        float Precio { get; set; }
    }
}

